# Databricks notebook source
# MAGIC %md
# MAGIC ### Incremental Data Ingestion

# COMMAND ----------

dbutils.widgets.text('src', '')

# COMMAND ----------

source = dbutils.widgets.get('src')
source

# COMMAND ----------

df = spark.readStream.format("cloudFiles") \
                     .option("cloudFiles.format", "csv") \
                     .option("cloudFiles.schemaLocation", f"/Volumes/workspace/bronze/bronzevolume/{source}/checkpoint") \
                     .option("cloudFiles.schemaEvolutionMode", "rescue") \
                     .load(f"/Volumes/workspace/raw/rawvolume/raw_data/{source}/")

# COMMAND ----------

df.writeStream \
  .format("delta") \
  .outputMode("append") \
  .trigger(once=True) \
  .option("checkpointLocation", f"/Volumes/workspace/bronze/bronzevolume/{source}/checkpoint") \
  .option("path", f"/Volumes/workspace/bronze/bronzevolume/{source}/data") \
  .start()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM delta.`/Volumes/workspace/bronze/bronzevolume/flights/data` 

# COMMAND ----------

