from pyspark.sql.functions import *
from pyspark.sql.types import *
import dlt

###################### Bookings ######################

# add the expectations
rules = {
    'rule1': "booking_id IS NOT NULL",
    'rule2': "passenger_id IS NOT NULL",
}

@dlt.table(
    name="bookings_stage"
)
def bookings_stage():
    return spark.readStream.format('delta').load("/Volumes/workspace/bronze/bronzevolume/bookings/data")

@dlt.view(
    name='bookings_transform'
)
def bookings_transform():
    df = spark.readStream.table("bookings_stage")
    return df.withColumn('amount', col("amount").cast(DoubleType())) \
        .withColumn('modifiedDate', current_timestamp()) \
        .withColumn('booking_date', to_date(col("booking_date"))) \
        .drop("_rescued_data")

@dlt.table(
    name="silver_bookings"
)
@dlt.expect_all_or_drop(rules)
def silver_bookings():
    return spark.readStream.table("bookings_transform")


###################### Flights ######################

@dlt.view(
    name="flights_stage"
)
def flights_stage():
    return spark.readStream.format('delta').load("/Volumes/workspace/bronze/bronzevolume/flights/data") \
        .withColumn('modifiedDate', current_timestamp()) \
        .drop("_rescued_data")


dlt.create_streaming_table("silver_flights")

dlt.create_auto_cdc_flow(
    target="silver_flights",
    source="flights_stage",
    keys=['flight_id'],
    sequence_by=col("modifiedDate"),
    stored_as_scd_type=1
)

###################### Passengers ######################

@dlt.view(
    name="passengers_stage"
)
def passengers_stage():
    return spark.readStream.format('delta').load("/Volumes/workspace/bronze/bronzevolume/customers/data") \
        .withColumn('modifiedDate', current_timestamp()) \
        .drop("_rescued_data")


dlt.create_streaming_table("silver_passengers")

dlt.create_auto_cdc_flow(
    target="silver_passengers",
    source="passengers_stage",
    keys=['passenger_id'],
    sequence_by=col("modifiedDate"),
    stored_as_scd_type=1
)

###################### Airports ######################

@dlt.view(
    name="airports_stage"
)
def passengers_stage():
    return spark.readStream.format('delta').load("/Volumes/workspace/bronze/bronzevolume/airports/data") \
        .withColumn('modifiedDate', current_timestamp()) \
        .drop("_rescued_data")


dlt.create_streaming_table("silver_airports")

dlt.create_auto_cdc_flow(
    target="silver_airports",
    source="airports_stage",
    keys=['airport_id'],
    sequence_by=col("modifiedDate"),
    stored_as_scd_type=1
)


###################### Business ######################

@dlt.table(
    name='Silver_business'
)
def Silver_business():
    df = dlt.readStream("silver_bookings") \
            .join(dlt.read("silver_passengers"), on='passenger_id') \
            .join(dlt.read("silver_flights"), on='flight_id') \
            .join(dlt.read("silver_airports"), on='airport_id') \
            .drop('modifiedDate')
    return df
