# Databricks notebook source
# MAGIC %md
# MAGIC ## Parameters

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Test workflow

# COMMAND ----------

key_columns_list = eval("['flight_id']")
cdc_column = "modifiedDate"
backdated_refresh = ""
source_object = "silver_flights"
source_schema = "silver"
target_object = "DimFlights"
target_schema = "gold"
catalog = "workspace"
dim_surrogate_key = "DimFlightsKey"

# COMMAND ----------

# MAGIC %md
# MAGIC ###### Dynamic workflow

# COMMAND ----------

# # Key column
# dbutils.widgets.text("key_columns", "['flight_id']")

# # CDC column (capture data change)
# dbutils.widgets.text("CDC_column", "")

# # Back-dated refresh
# dbutils.widgets.text("backdated_refresh", "")

# # Source object
# dbutils.widgets.text("source_object", "")

# # Source schema
# dbutils.widgets.text("source_schema", "")

# # Target object
# dbutils.widgets.text("target_object", "")

# # Target schema
# dbutils.widgets.text("target_schema", "")

# # Catalog
# dbutils.widgets.text("catelog", "")

# # Surrogate key
# dbutils.widgets.text("surrogate_key", "")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fetch Parameters

# COMMAND ----------

# key_columns_list = dbutils.widgets.get("key_columns")
# cdc_column = dbutils.widgets.get("CDC_column")
# backdated_refresh = dbutils.widgets.get("backdated_refresh")
# source_object = dbutils.widgets.get("source_object")
# source_schema = dbutils.widgets.get("source_schema")
# target_object = dbutils.widgets.get("target_object")
# target_schema = dbutils.widgets.get("target_schema")
# catalog = dbutils.widgets.get("catelog")
# dim_surrogate_key = dbutils.widgets.get("surrogate_key")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Incremental Data Ingestion

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create Latest Load Date

# COMMAND ----------

# if not backdaated_refresh
if len(backdated_refresh) == 0:
  
  # check whether the table exists 
  if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
    # exists, this is the incremental load
    latest_load_date = spark.sql(f"SELECT MAX({cdc_column}) FROM `{catalog}`.`{target_schema}`.`{target_object}`").collect()[0][0]
  else:
    # don't exist, this is the initial load
    latest_load_date = '1900-01-01 00:00:00'
else:
  latest_load_date = backdated_refresh

# COMMAND ----------

latest_load_date

# COMMAND ----------

df_src = spark.sql(f"SELECT * FROM `{catalog}`.`{source_schema}`.`{source_object}` WHERE {cdc_column} > '{latest_load_date}'")

# COMMAND ----------

df_src.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check whether is new data

# COMMAND ----------

# MAGIC %md
# MAGIC #### Create pseduo table

# COMMAND ----------

if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
  # key columns for incremental load
  key_columns = ', '.join(key_columns_list)
  df_tgt = spark.sql(f"SELECT {key_columns}, {dim_surrogate_key}, create_date, update_date FROM `{catalog}`.`{target_schema}`.`{target_object}`")
else:
  # key columns for initial load
  key_col_for_pseduo = [f"'' AS {col}" for col in key_columns_list]
  key_col_for_pseduo = ', '.join(key_col_for_pseduo)

  df_tgt = spark.sql(f"""
                     SELECT 
                        {key_col_for_pseduo}, 
                        CAST('0' AS INT) AS `{dim_surrogate_key}`, 
                        CAST('1900-01-01 00:00:00' AS TIMESTAMP) AS create_date, 
                        CAST('1900-01-01 00:00:00' AS TIMESTAMP) AS update_date
                     WHERE 1=0""")

# COMMAND ----------

df_tgt.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Join the table

# COMMAND ----------

df_src.createOrReplaceTempView("df_src")
df_tgt.createOrReplaceTempView("df_tgt")

join_condition = ' AND '.join([f"df_src.`{col}` = df_tgt.`{col}`" for col in key_columns_list])

df_join = spark.sql(f"""
              SELECT
                df_src.*,
                df_tgt.`{dim_surrogate_key}`,
                df_tgt.create_date,
                df_tgt.update_date
              FROM df_src
              LEFT JOIN df_tgt
              ON {join_condition}
          """)

# COMMAND ----------

df_join.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Prepare update record

# COMMAND ----------

df_new = df_join.filter(col(f'{dim_surrogate_key}').isNull())
df_update = df_join.filter(col(f'{dim_surrogate_key}').isNotNull())

# COMMAND ----------

# update with update_data
df_update_enriched = df_update.withColumn('update_date', current_timestamp())

# COMMAND ----------

if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
    max_surrogate_key = spark.sql(f"SELECT MAX({dim_surrogate_key}) FROM `{catalog}`.`{target_schema}`.`{target_object}`").collect()[0][0]
    df_new_enriched = df_new.withColumn(f'{dim_surrogate_key}', lit(max_surrogate_key + 1) + monotonically_increasing_id()) \
                                           .withColumn('update_date', current_timestamp()) \
                                           .withColumn('create_date', current_timestamp())
else:
    max_surrogate_key = 0
    df_new_enriched = df_new.withColumn(f'{dim_surrogate_key}', lit(max_surrogate_key + 1) + monotonically_increasing_id()) \
                            .withColumn('create_date', current_timestamp()) \
                            .withColumn('update_date', current_timestamp())

# COMMAND ----------

max_surrogate_key

# COMMAND ----------

# MAGIC %md
# MAGIC #### Union update and new records

# COMMAND ----------

df_union = df_update_enriched.unionByName(df_new_enriched)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upsert

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

# if table exists do the upsert, or insert
if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
    dlt_obj = DeltaTable.forName(spark, f'`{catalog}`.`{target_schema}`.`{target_object}`')
    dlt_obj.alias('tgt').merge(df_union.alias('src'), f'tgt.{dim_surrogate_key} = src.{dim_surrogate_key}') \
                        .whenMatchedUpdateAll(condition=f'src.{cdc_column} >= tgt.{cdc_column}') \
                        .whenNotMatchedInsertAll() \
                        .execute()
else:
    df_union.write.mode('overwrite') \
            .saveAsTable(f"`{catalog}`.`{target_schema}`.`{target_object}`")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM workspace.gold.dimflights

# COMMAND ----------

