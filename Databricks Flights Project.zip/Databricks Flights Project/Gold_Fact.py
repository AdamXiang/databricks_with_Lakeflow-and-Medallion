# Databricks notebook source
# MAGIC %md
# MAGIC ### Set Parameters

# COMMAND ----------

key_columns_list = eval("['flight_id']")
cdc_column = "modifiedDate"
backdated_refresh = ""
source_object = "silver_bookings"
source_schema = "silver"
target_object = "DimBookings"
target_schema = "gold"
catalog = "workspace"
dim_surrogate_key = "DimBookingsKey"

# Source Fact Table
fact_table = f"{catalog}.{source_schema}.{source_object}"

# Fact key columns
fact_key_cols = ['DimPassengersKey', 'DimFlightsKey', 'DimAirportsKey', 'booking_date']

# COMMAND ----------

# dimension we want to join
dimension = [
    {
        'table': 'workspace.gold.DimPassengers',
        'alias': "DimPassengers",
        'join_keys': [('passenger_id', 'passenger_id')] #(fact_col, dim_col)
    },
    {
        'table': 'workspace.gold.DimFlights',
        'alias': "DimFlights",
        'join_keys': [('flight_id', 'flight_id')] #(fact_col, dim_col)
    },
    {
        'table': 'workspace.gold.DimAirports',
        'alias': "DimAirports",
        'join_keys': [('airport_id', 'airport_id')] #(fact_col, dim_col)
    }

]

# columns we want to keep from fact table
fact_columns = ['amount', 'booking_date', 'modifiedDate']

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get the latest load date

# COMMAND ----------

# if not backdaated_refresh
if len(backdated_refresh) == 0:
  
  # check whether the table exists 
  if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
    # exists, this is the incremental load
    latest_load_date = spark.sql(f"SELECT MAX({cdc_column}) FROM `{catalog}`.`{target_schema}`.`{target_object}`").collect()[0][0]
  else:
    # don't exist, this is the initial load
    latest_load_date = '1900-01-01 00:00:00'
else:
  latest_load_date = backdated_refresh

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dynamic Fact Table Query

# COMMAND ----------

def generate_fact_table_query(fact_table, dimensions, fact_columns, cdc_column, processing_date):
  fact_alias = 'f'

  # columns select
  select_cols = [f"{fact_alias}.{col}" for col in fact_columns]

  # dynamically join
  join_conds = []
  for dim in dimensions:
    table_full = dim['table']
    table_alias = dim['alias']
    table_name = table_full.split('.')[-1]

    surrogate_key = f'{table_alias}.{table_name}Key'

    select_cols.append(surrogate_key)

    # on clause
    on_condition = [
      f"{fact_alias}.{fk} = {table_alias}.{dk} for fk, dk in dim['join_keys']"
    ]

    join_clause = f"LEFT JOIN {table_full} {table_alias} ON + ' AND '.join(on_condition)"
    join_conds.append(join_clause)

    # select and join
    select_clause = ', \n'.join(select_cols)
    join_clause = ' \n'.join(join_conds)

    # where
    where_clause = f'{fact_alias}.{cdc_column} >= Date("{latest_load_date}")'

    # final query
    query = f"""
      SELECT 
        {select_clause}
      FROM 
        {fact_table} {fact_alias}
      {join_clause}
      WHERE
        {where_clause}
    """.strip()

    return query

# COMMAND ----------

query = generate_fact_table_query(fact_table, dimension, fact_columns, cdc_column, latest_load_date)
print(query)

# COMMAND ----------

df_fact = spark.sql(query)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Upsert

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

fact_key_merge_cond = ' AND '.join([f"src.{k} = tgt.{k}" for k in fact_key_cols])

# COMMAND ----------

# if table exists do the upsert, or insert
if spark.catalog.tableExists(f"`{catalog}`.`{target_schema}`.`{target_object}`"):
    dlt_obj = DeltaTable.forName(spark, f'`{catalog}`.`{target_schema}`.`{target_object}`')
    dlt_obj.alias('tgt').merge(df_fact.alias('src'), fact_key_merge_cond) \
                        .whenMatchedUpdateAll(condition=f'src.{cdc_column} >= tgt.{cdc_column}') \
                        .whenNotMatchedInsertAll() \
                        .execute()
else:
    df_fact.write.mode('overwrite') \
            .saveAsTable(f"`{catalog}`.`{target_schema}`.`{target_object}`")