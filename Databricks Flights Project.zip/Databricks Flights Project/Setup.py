# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE VOLUME workspace.raw.rawVolume

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/raw_data")

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/raw_data/bookings")
dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/raw_data/flights")
dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/raw_data/customers")
dbutils.fs.mkdirs("/Volumes/workspace/raw/rawvolume/raw_data/airports")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA workspace.bronze;
# MAGIC CREATE SCHEMA workspace.silver;
# MAGIC CREATE SCHEMA workspace.gold;

# COMMAND ----------

