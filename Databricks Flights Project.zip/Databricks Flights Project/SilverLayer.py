# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
import dlt

# COMMAND ----------

@dlt.table(
    name="bookings_stage"
)
def bookings_stage():
    return spark.readStream.format('delta').load("/Volumes/workspace/bronze/bronzevolume/bookings/data")

# COMMAND ----------

@dlt.view(
    name='bookings_transform'
)
def bookings_transform():
    df = spark.readStream.table("bookings_stage")
    return df.withColumn('amount', col("amount").cast(DoubleType())) \
        .withColumn('modifiedDate', current_timestamp()) \
        .withColumn('booking_date', to_date(col("booking_date"))) \
        .drop("_rescued_data")

# COMMAND ----------

# add the expectations
rules = {
    'rule1': "booking_id IS NOT NULL",
    'rule2': "passenger_id IS NOT NULL",
}

# COMMAND ----------

@dlt.table(
    name="silver_bookings"
)
@dlt.expect_all(rules)
def silver_bookings():
    return dlt.read("bookings_transform")