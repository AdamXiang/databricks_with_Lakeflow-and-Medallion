# Databricks notebook source
source = [
    {"src": "airports"},
    {"src": "bookings"},
    {"src": "flights"},
    {"src": "customers"}
]

# COMMAND ----------

dbutils.jobs.taskValues.set(key="source_key", value=source)

# COMMAND ----------

